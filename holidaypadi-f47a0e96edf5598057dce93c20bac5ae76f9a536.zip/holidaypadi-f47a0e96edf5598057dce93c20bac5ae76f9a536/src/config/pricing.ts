export const PRICING = {
  CURATION_FEE: 98350 // ₦98,350 service charge
} as const;
